package edu.umb.cs.cs681.hw2;


public interface Command
{
	  public abstract void execute();
}