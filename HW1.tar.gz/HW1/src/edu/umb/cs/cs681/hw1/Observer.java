package edu.umb.cs.cs681.hw1;

public interface Observer 
{
	public abstract void update(Observable obs,Object arg);
}
